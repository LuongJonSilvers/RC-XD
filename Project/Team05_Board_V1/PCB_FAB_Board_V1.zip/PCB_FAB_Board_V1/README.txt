The board outline is defined by a 10mil trace defined on all gerbers.

The board dimensions are 7.2 x 5.8 inches.